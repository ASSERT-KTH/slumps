#include <stdio.h>

int main()
{
	char *object = 0;

	if (object == NULL) {
		puts("object is null");
	}
	return 0;
}