#include <stdio.h>

int main()
{
	printf("\033[7mReversed\033[m Normal\n");

	return 0;
}