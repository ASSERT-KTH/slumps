typedef struct Point
{
  int x;
  int y;
} Point;