der|C}}==
See [[Arithmetic Evaluator/C]].