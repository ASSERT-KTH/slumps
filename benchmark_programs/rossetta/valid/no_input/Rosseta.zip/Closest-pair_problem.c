der|C}}==
See [[Closest-pair problem/C]]