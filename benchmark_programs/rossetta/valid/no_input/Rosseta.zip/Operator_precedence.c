der|C}}==
Same as [http://rosettacode.org/wiki/Operator_precedence#C.2B.2B|See C++].