der|C}}==

See [[RCRPG/C]].