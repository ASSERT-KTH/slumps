#include <string.h>

int main(void) 
{
  const char *string = "Hello, world!";
  size_t length = strlen(string);
         
  return 0;
}