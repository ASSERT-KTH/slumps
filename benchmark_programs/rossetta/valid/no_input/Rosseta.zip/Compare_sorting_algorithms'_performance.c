#ifndef _CSEQUENCE_H
#define _CSEQUENCE_H
#include <stdlib.h>

void setfillconst(double c);
void fillwithconst(double *v, int n);
void fillwithrrange(double *v, int n);
void shuffledrange(double *v, int n);
#endif