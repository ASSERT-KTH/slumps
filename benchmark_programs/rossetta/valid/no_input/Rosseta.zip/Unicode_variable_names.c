
#include<stdio.h>

int main() {
    int Δ = 1;
    
    Δ++;
    
    printf("%d",Δ);
    
    return 0;
}
