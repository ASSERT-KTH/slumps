der|C}}==
See [[Column Aligner/C]]