#include <stdio.h>

int
main()
{
	puts("£");
	puts("\302\243"); /* if your terminal is utf-8 */
	return 0;
}