der|C}}==
See [[Remote agent/Simulation/C]]