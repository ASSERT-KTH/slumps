der|C}}==

* see [[Example:Hough transform/C]]