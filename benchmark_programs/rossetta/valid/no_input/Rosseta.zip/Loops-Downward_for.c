int i;
for(i = 10; i >= 0; --i)
  printf("%d\n",i);