#include <stdint.h>

int_least32_t foo;