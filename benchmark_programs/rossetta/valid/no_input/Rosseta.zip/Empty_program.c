main()
{
  return 0;
}