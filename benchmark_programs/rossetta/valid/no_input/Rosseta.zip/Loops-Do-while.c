int val = 0;
do{
   val++;
   printf("%d\n",val);
}while(val % 6 != 0);