int i;
for(i = 1; i < 10; i += 2)
  printf("%d\n", i);