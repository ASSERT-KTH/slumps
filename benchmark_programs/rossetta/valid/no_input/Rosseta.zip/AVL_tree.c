der|C}}==

See [[AVL_tree/C|AVL tree/C]]