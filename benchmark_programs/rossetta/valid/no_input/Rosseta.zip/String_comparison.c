
/* WRONG! */
if (strcmp(a,b)) action_on_equality();
