
#include<stdio.h>

#define start main()

int start
{
	printf("Hello World !");
	return 0;
}
