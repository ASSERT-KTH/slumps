der|C}}==
See [[Go Fish/C]]